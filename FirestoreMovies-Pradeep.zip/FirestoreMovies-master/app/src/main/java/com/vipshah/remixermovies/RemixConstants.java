package com.vipshah.remixermovies;

public class RemixConstants {

    public static final String COLLECTION_MOVIES = "movies";
    public static final String COLLECTION_REVIEWS = "reviews";
    public static final String COLLECTION_RATINGS = "ratings";
}
