package com.vipshah.remixermovies.models;

public class RemixMovies {

    public final RemixMovie[] results;

    public RemixMovies(RemixMovie[] results) {
        this.results = results;
    }
}
