package com.vipshah.remixermovies.base;

public interface BaseView {

    void showLoading();

    void hideLoading();
}
